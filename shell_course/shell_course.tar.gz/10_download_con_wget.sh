# ! /bin/bash
# Programa para ejemplificar como se realiza la descarga de información desde internet utilizando el comando wget
# Autor: LMM - mi_email@dominio.com
echo -e "Descargando información de internet\n"
wget https://downloads.apache.org/tomcat/tomcat-8/v8.5.54/bin/apache-tomcat-8.5.54.zip
