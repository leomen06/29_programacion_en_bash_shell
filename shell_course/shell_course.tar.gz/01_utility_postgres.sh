# !/bin/bash/
# El primer comentarios es importante para que el sistema reconozca que este archivo se debe ejecutar.

echo "Hola"
