# !/bin/bash
# Programa para revisar la declaracion de variables
echo "Este es mi nombre: $nombre, $apellido, y mi edad: $edad"
